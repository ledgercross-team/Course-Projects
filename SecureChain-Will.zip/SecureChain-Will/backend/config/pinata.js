module.exports = {
  apiKey: process.env.PINATA_API_KEY,
  apiSecret: process.env.PINATA_API_SECRET,
  jwt: process.env.PINATA_JWT,
  gatewayUrl: process.env.PINATA_GATEWAY_URL || "https://gateway.pinata.cloud/ipfs",
  pinFileUrl: "https://api.pinata.cloud/pinning/pinFileToIPFS",
  unpinUrl: (cid) => `https://api.pinata.cloud/pinning/unpin/${cid}`,
};
