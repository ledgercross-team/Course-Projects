const jwt = require("jsonwebtoken");
const { ethers } = require("ethers");
const User = require("../models/User");

const WALLET_REGEX = /^0x[a-fA-F0-9]{40}$/;

function signToken(user) {
  return jwt.sign(
    { id: user._id, wallet: user.wallet, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );
}

/// POST /api/register
/// Registers a new user tied to a MetaMask wallet address.
async function register(req, res, next) {
  try {
    const { name, email, wallet, role } = req.body;

    if (!name || !email || !wallet) {
      return res.status(400).json({ success: false, message: "name, email, and wallet are required" });
    }

    if (!WALLET_REGEX.test(wallet)) {
      return res.status(400).json({ success: false, message: "Invalid wallet address" });
    }

    const normalizedWallet = ethers.getAddress(wallet).toLowerCase();

    const existing = await User.findOne({
      $or: [{ email: email.toLowerCase() }, { wallet: normalizedWallet }],
    });
    if (existing) {
      return res.status(409).json({ success: false, message: "User already registered" });
    }

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      wallet: normalizedWallet,
      role: ["creator", "witness", "admin", "beneficiary"].includes(role) ? role : "creator",
    });

    const token = signToken(user);
    return res.status(201).json({ success: true, token, user });
  } catch (err) {
    next(err);
  }
}

/// POST /api/login
/// Prototype login: verifies a signed message proves ownership of the wallet,
/// then issues a JWT. `signature` is produced client-side via
/// `signer.signMessage(message)` in ethers.js.
async function login(req, res, next) {
  try {
    const { wallet, message, signature } = req.body;

    if (!wallet || !message || !signature) {
      return res.status(400).json({ success: false, message: "wallet, message, and signature are required" });
    }

    if (!WALLET_REGEX.test(wallet)) {
      return res.status(400).json({ success: false, message: "Invalid wallet address" });
    }

    const recovered = ethers.verifyMessage(message, signature);
    if (recovered.toLowerCase() !== wallet.toLowerCase()) {
      return res.status(401).json({ success: false, message: "Signature does not match wallet" });
    }

    const user = await User.findOne({ wallet: wallet.toLowerCase() });
    if (!user) {
      return res.status(404).json({ success: false, message: "Wallet not registered" });
    }

    const token = signToken(user);
    return res.json({ success: true, token, user });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login };
