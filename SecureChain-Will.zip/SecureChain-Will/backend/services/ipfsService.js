const fs = require("fs");
const axios = require("axios");
const FormData = require("form-data");
const pinataConfig = require("../config/pinata");

/// Uploads an (already encrypted) file to IPFS via Pinata and returns the CID.
async function uploadToIPFS(filePath, fileName) {
  const data = new FormData();
  data.append("file", fs.createReadStream(filePath), fileName);
  data.append(
    "pinataMetadata",
    JSON.stringify({ name: fileName, keyvalues: { app: "SecureChainWill" } })
  );
  data.append("pinataOptions", JSON.stringify({ cidVersion: 1 }));

  const headers = pinataConfig.jwt
    ? { Authorization: `Bearer ${pinataConfig.jwt}`, ...data.getHeaders() }
    : {
        pinata_api_key: pinataConfig.apiKey,
        pinata_secret_api_key: pinataConfig.apiSecret,
        ...data.getHeaders(),
      };

  const response = await axios.post(pinataConfig.pinFileUrl, data, {
    maxBodyLength: Infinity,
    headers,
  });

  return response.data.IpfsHash; // CID
}

/// Unpins a file from Pinata (e.g. if a will is deleted before approval).
async function unpinFromIPFS(cid) {
  const headers = pinataConfig.jwt
    ? { Authorization: `Bearer ${pinataConfig.jwt}` }
    : {
        pinata_api_key: pinataConfig.apiKey,
        pinata_secret_api_key: pinataConfig.apiSecret,
      };

  await axios.delete(pinataConfig.unpinUrl(cid), { headers });
}

function gatewayUrlFor(cid) {
  return `${pinataConfig.gatewayUrl}/${cid}`;
}

module.exports = { uploadToIPFS, unpinFromIPFS, gatewayUrlFor };
