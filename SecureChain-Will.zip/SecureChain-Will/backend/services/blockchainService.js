const { ethers } = require("ethers");
const contractABI = require("../../smart-contract/out/WillRegistry.sol/WillRegistry.json").abi;
// NOTE: the ABI above is only available after `forge build` has produced
// artifacts under smart-contract/out/. Until then, replace this require with
// a checked-in copy of the ABI (see frontend/src/contracts/WillRegistry.json).

let provider;
let adminWallet;
let contract;

function getContract() {
  if (contract) return contract;

  const rpcUrl = process.env.SEPOLIA_RPC_URL;
  const privateKey = process.env.ADMIN_PRIVATE_KEY;
  const address = process.env.CONTRACT_ADDRESS;

  if (!rpcUrl || !privateKey || !address) {
    throw new Error(
      "Blockchain env vars missing: SEPOLIA_RPC_URL, ADMIN_PRIVATE_KEY, CONTRACT_ADDRESS"
    );
  }

  provider = new ethers.JsonRpcProvider(rpcUrl);
  adminWallet = new ethers.Wallet(privateKey, provider);
  contract = new ethers.Contract(address, contractABI, adminWallet);

  return contract;
}

/// Admin-signed on-chain call: marks death/condition as verified.
async function verifyDeathOnChain(willId) {
  const c = getContract();
  const tx = await c.verifyDeath(willId);
  return tx.wait();
}

/// Admin-signed on-chain call: releases the will to the beneficiary.
async function releaseWillOnChain(willId) {
  const c = getContract();
  const tx = await c.releaseWill(willId);
  return tx.wait();
}

/// Read-only: fetches will metadata directly from the contract.
async function getWillOnChain(willId) {
  const c = getContract();
  return c.getWill(willId);
}

/// Read-only: checks access permission as recorded on-chain.
async function canAccessOnChain(willId, walletAddress) {
  const c = getContract();
  return c.canAccess(willId, walletAddress);
}

module.exports = {
  getContract,
  verifyDeathOnChain,
  releaseWillOnChain,
  getWillOnChain,
  canAccessOnChain,
};
