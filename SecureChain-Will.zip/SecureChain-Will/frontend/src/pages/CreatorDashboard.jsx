import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../context/WalletContext.jsx";
import WillCard from "../components/WillCard.jsx";

export default function CreatorDashboard() {
  const [wills, setWills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .get("/myWills")
      .then(({ data }) => setWills(data.wills))
      .catch((err) => setError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0 }}>My Wills</h2>
        <Link className="btn" to="/upload">
          + Upload New Will
        </Link>
      </div>

      {loading && <p style={{ color: "var(--muted)" }}>Loading...</p>}
      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}
      {!loading && wills.length === 0 && (
        <p style={{ color: "var(--muted)" }}>You haven't created any wills yet.</p>
      )}

      <div className="grid grid-2">
        {wills.map((w) => (
          <WillCard key={w._id} will={w} />
        ))}
      </div>
    </div>
  );
}
