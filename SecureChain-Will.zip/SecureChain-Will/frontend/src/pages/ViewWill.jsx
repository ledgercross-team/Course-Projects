import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../context/WalletContext.jsx";
import StatusBadge from "../components/StatusBadge.jsx";

export default function ViewWill() {
  const { id } = useParams();
  const [will, setWill] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get(`/will/${id}`)
      .then(({ data }) => setWill(data.will))
      .catch((err) => setError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <p style={{ color: "var(--muted)" }}>Loading...</p>;
  if (error) return <p style={{ color: "var(--danger)" }}>{error}</p>;
  if (!will) return null;

  return (
    <div className="card" style={{ maxWidth: 560 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 style={{ margin: 0 }}>Will #{will.onChainId ?? "pending"}</h2>
        <StatusBadge status={will.status} />
      </div>

      <div style={{ marginTop: 16, fontSize: 14, display: "grid", gap: 8, color: "var(--muted)" }}>
        <div><strong style={{ color: "var(--text)" }}>Creator:</strong> {will.creatorWallet}</div>
        <div><strong style={{ color: "var(--text)" }}>Witness:</strong> {will.witnessWallet}</div>
        <div><strong style={{ color: "var(--text)" }}>Beneficiary:</strong> {will.beneficiaryWallet}</div>
        <div><strong style={{ color: "var(--text)" }}>IPFS CID:</strong> {will.cid}</div>
        <div><strong style={{ color: "var(--text)" }}>Document Hash:</strong> {will.hash}</div>
        <div><strong style={{ color: "var(--text)" }}>Created:</strong> {new Date(will.createdAt).toLocaleString()}</div>
      </div>

      {will.gatewayUrl ? (
        <a className="btn" style={{ marginTop: 20 }} href={will.gatewayUrl} target="_blank" rel="noreferrer">
          Download Encrypted Document
        </a>
      ) : (
        <p style={{ marginTop: 20, fontSize: 13, color: "var(--muted)" }}>
          Document access is not available until this will is released.
        </p>
      )}

      {will.gatewayUrl && (
        <p style={{ fontSize: 12, color: "var(--muted)", marginTop: 8 }}>
          Note: the downloaded file is AES-encrypted. Decryption happens via
          the backend's key-holder for authorized parties in this prototype.
        </p>
      )}
    </div>
  );
}
