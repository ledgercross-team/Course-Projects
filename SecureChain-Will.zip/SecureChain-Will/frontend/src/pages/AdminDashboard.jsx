import React, { useEffect, useState } from "react";
import { api } from "../context/WalletContext.jsx";
import WillCard from "../components/WillCard.jsx";

export default function AdminDashboard() {
  const [wills, setWills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState(null);

  function load() {
    setLoading(true);
    api
      .get("/myWills")
      .then(({ data }) => setWills(data.wills))
      .catch((err) => setError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function handleVerify(will) {
    setBusyId(will._id);
    setError(null);
    try {
      await api.post("/verify", { willId: will._id, onChainId: will.onChainId });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleRelease(will) {
    setBusyId(will._id);
    setError(null);
    try {
      await api.post("/release", { willId: will._id, onChainId: will.onChainId });
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <h2>Admin Panel</h2>
      <p style={{ color: "var(--muted)" }}>
        Verify death/condition and release wills to their beneficiaries.
      </p>

      {loading && <p style={{ color: "var(--muted)" }}>Loading...</p>}
      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}

      <div className="grid grid-2">
        {wills.map((w) => (
          <WillCard
            key={w._id}
            will={w}
            actions={
              <>
                {w.status === "WitnessApproved" && (
                  <button className="btn" disabled={busyId === w._id} onClick={() => handleVerify(w)}>
                    {busyId === w._id ? "Verifying..." : "Verify Death"}
                  </button>
                )}
                {w.status === "Verified" && (
                  <button className="btn" disabled={busyId === w._id} onClick={() => handleRelease(w)}>
                    {busyId === w._id ? "Releasing..." : "Release Will"}
                  </button>
                )}
              </>
            }
          />
        ))}
      </div>
    </div>
  );
}
