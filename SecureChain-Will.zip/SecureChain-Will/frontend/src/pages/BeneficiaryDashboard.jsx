import React, { useEffect, useState } from "react";
import { api } from "../context/WalletContext.jsx";
import WillCard from "../components/WillCard.jsx";

export default function BeneficiaryDashboard() {
  const [wills, setWills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .get("/myWills")
      .then(({ data }) => setWills(data.wills))
      .catch((err) => setError(err.response?.data?.message || err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h2>Released Wills</h2>
      {loading && <p style={{ color: "var(--muted)" }}>Loading...</p>}
      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}
      {!loading && wills.length === 0 && (
        <p style={{ color: "var(--muted)" }}>
          No wills have been released to you yet. Check back after the admin
          verifies and releases a will naming you as beneficiary.
        </p>
      )}

      <div className="grid grid-2">
        {wills.map((w) => (
          <WillCard key={w._id} will={w} />
        ))}
      </div>
    </div>
  );
}
