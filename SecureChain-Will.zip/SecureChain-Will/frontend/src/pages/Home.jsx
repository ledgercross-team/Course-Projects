import React from "react";
import { Link } from "react-router-dom";
import { useWallet } from "../context/WalletContext.jsx";

export default function Home() {
  const { user } = useWallet();

  return (
    <div style={{ maxWidth: 720 }}>
      <h1>SecureChain Will</h1>
      <p style={{ color: "var(--muted)", lineHeight: 1.6 }}>
        A blockchain-based digital will verification prototype. Documents are
        encrypted, pinned to IPFS, and referenced on-chain by hash — with
        release gated behind witness approval and admin verification.
      </p>

      <div className="card" style={{ marginTop: 24, background: "var(--surface-2)" }}>
        <strong>Prototype notice</strong>
        <p style={{ color: "var(--muted)", fontSize: 13, marginTop: 6 }}>
          This is a university capstone demonstration. It is not a substitute
          for a legally binding will or estate planning process.
        </p>
      </div>

      {!user && (
        <div style={{ marginTop: 24, display: "flex", gap: 12 }}>
          <Link className="btn" to="/login">
            Get started
          </Link>
        </div>
      )}
    </div>
  );
}
