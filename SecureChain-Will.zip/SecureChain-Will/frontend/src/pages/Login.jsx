import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useWallet, api } from "../context/WalletContext.jsx";
import { getSigner } from "../utils/web3";

export default function Login() {
  const { address, connect, setSession } = useWallet();
  const navigate = useNavigate();

  const [mode, setMode] = useState("login"); // login | register
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("creator");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function ensureConnected() {
    if (address) return address;
    return connect();
  }

  async function handleLogin() {
    setError(null);
    setLoading(true);
    try {
      const wallet = await ensureConnected();
      const signer = await getSigner();

      const message = `Sign in to SecureChain Will\nWallet: ${wallet}\nTimestamp: ${Date.now()}`;
      const signature = await signer.signMessage(message);

      const { data } = await api.post("/login", { wallet, message, signature });
      setSession(data.token, data.user);
      navigate(`/${data.user.role}`);
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister() {
    setError(null);
    setLoading(true);
    try {
      const wallet = await ensureConnected();
      const { data } = await api.post("/register", { name, email, wallet, role });
      setSession(data.token, data.user);
      navigate(`/${data.user.role}`);
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 420 }}>
      <h2>{mode === "login" ? "Log in" : "Register"}</h2>

      <div className="card" style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
        <button
          className={`btn ${mode === "login" ? "" : "btn-secondary"}`}
          onClick={() => setMode("login")}
        >
          I already have an account
        </button>
        <button
          className={`btn ${mode === "register" ? "" : "btn-secondary"}`}
          onClick={() => setMode("register")}
        >
          New here — register
        </button>
      </div>

      <div className="card">
        {mode === "register" && (
          <>
            <div className="form-group">
              <label>Full name</label>
              <input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="form-group">
              <label>Role</label>
              <select value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="creator">Creator</option>
                <option value="witness">Witness</option>
                <option value="beneficiary">Beneficiary</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </>
        )}

        {error && <p style={{ color: "var(--danger)", fontSize: 13 }}>{error}</p>}

        <button
          className="btn"
          style={{ width: "100%" }}
          disabled={loading}
          onClick={mode === "login" ? handleLogin : handleRegister}
        >
          {loading ? "Working..." : mode === "login" ? "Connect & Sign In" : "Connect & Register"}
        </button>
      </div>
    </div>
  );
}
