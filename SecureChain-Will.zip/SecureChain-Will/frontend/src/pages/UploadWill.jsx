import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import UploadForm from "../components/UploadForm.jsx";

export default function UploadWill() {
  const [success, setSuccess] = useState(null);
  const navigate = useNavigate();

  return (
    <div>
      <h2>Upload Will</h2>
      <p style={{ color: "var(--muted)", maxWidth: 480 }}>
        Your document will be encrypted client-side workflow (AES on the
        backend), pinned to IPFS, and its hash + CID registered on-chain.
      </p>

      <UploadForm onSuccess={setSuccess} />

      {success && (
        <div className="card" style={{ marginTop: 20, maxWidth: 480 }}>
          <strong>Will submitted successfully 🎉</strong>
          <p style={{ fontSize: 13, color: "var(--muted)" }}>
            On-chain ID: {success.onChainId ?? "pending confirmation"}
            <br />
            Tx hash: {success.txHash?.slice(0, 20)}...
          </p>
          <button className="btn" onClick={() => navigate("/creator")}>
            Go to My Wills
          </button>
        </div>
      )}
    </div>
  );
}
