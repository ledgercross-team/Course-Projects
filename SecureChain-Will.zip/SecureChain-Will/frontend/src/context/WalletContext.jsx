import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { connectWallet, hasMetaMask } from "../utils/web3";
import api from "../api/axios";

const WalletContext = createContext(null);

export function WalletProvider({ children }) {
  const [address, setAddress] = useState(null);
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("scw_user");
    return stored ? JSON.parse(stored) : null;
  });
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!hasMetaMask()) return;
    window.ethereum.on?.("accountsChanged", (accounts) => {
      setAddress(accounts[0] || null);
    });
  }, []);

  const connect = useCallback(async () => {
    setConnecting(true);
    setError(null);
    try {
      const { address: addr } = await connectWallet();
      setAddress(addr);
      return addr;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setConnecting(false);
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("scw_token");
    localStorage.removeItem("scw_user");
    setUser(null);
  }, []);

  const setSession = useCallback((token, userData) => {
    localStorage.setItem("scw_token", token);
    localStorage.setItem("scw_user", JSON.stringify(userData));
    setUser(userData);
  }, []);

  const value = {
    address,
    user,
    connecting,
    error,
    connect,
    logout,
    setSession,
    isAuthenticated: Boolean(user),
  };

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within a WalletProvider");
  return ctx;
}

// re-export for convenience so pages can hit the API without importing twice
export { api };
