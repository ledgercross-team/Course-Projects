import { BrowserProvider, Contract } from "ethers";
import contractData from "../contracts/WillRegistry.json";

const CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS;
const EXPECTED_CHAIN_ID = Number(import.meta.env.VITE_CHAIN_ID || 11155111); // Sepolia

export const WillStatus = ["Created", "WitnessApproved", "Verified", "Released", "Rejected"];

export function hasMetaMask() {
  return typeof window !== "undefined" && Boolean(window.ethereum);
}

export async function connectWallet() {
  if (!hasMetaMask()) {
    throw new Error("MetaMask is not installed. Please install it to continue.");
  }

  const provider = new BrowserProvider(window.ethereum);
  const accounts = await provider.send("eth_requestAccounts", []);
  const network = await provider.getNetwork();

  if (Number(network.chainId) !== EXPECTED_CHAIN_ID) {
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: `0x${EXPECTED_CHAIN_ID.toString(16)}` }],
      });
    } catch (switchError) {
      console.warn("Could not switch network automatically:", switchError);
    }
  }

  return { provider, address: accounts[0] };
}

export async function getSigner() {
  if (!hasMetaMask()) throw new Error("MetaMask is not installed");
  const provider = new BrowserProvider(window.ethereum);
  return provider.getSigner();
}

export async function getContractReadOnly() {
  if (!hasMetaMask()) throw new Error("MetaMask is not installed");
  const provider = new BrowserProvider(window.ethereum);
  return new Contract(CONTRACT_ADDRESS, contractData.abi, provider);
}

export async function getContractWithSigner() {
  const signer = await getSigner();
  return new Contract(CONTRACT_ADDRESS, contractData.abi, signer);
}

/// Calls createWill() on-chain and returns { onChainId, txHash }.
export async function createWillOnChain({ witness, beneficiary, cid, hash }) {
  const contract = await getContractWithSigner();
  const tx = await contract.createWill(witness, beneficiary, cid, hash);
  const receipt = await tx.wait();

  const event = receipt.logs
    .map((log) => {
      try {
        return contract.interface.parseLog(log);
      } catch {
        return null;
      }
    })
    .find((parsed) => parsed && parsed.name === "WillCreated");

  const onChainId = event ? Number(event.args.id) : null;
  return { onChainId, txHash: receipt.hash };
}

export async function approveByWitnessOnChain(onChainId) {
  const contract = await getContractWithSigner();
  const tx = await contract.approveByWitness(onChainId);
  return tx.wait();
}

export async function getWillOnChain(onChainId) {
  const contract = await getContractReadOnly();
  const raw = await contract.getWill(onChainId);
  return {
    id: Number(raw.id),
    creator: raw.creator,
    witness: raw.witness,
    beneficiary: raw.beneficiary,
    ipfsCID: raw.ipfsCID,
    documentHash: raw.documentHash,
    status: WillStatus[Number(raw.status)],
    createdAt: Number(raw.createdAt),
  };
}

export async function canAccessOnChain(onChainId, address) {
  const contract = await getContractReadOnly();
  return contract.canAccess(onChainId, address);
}
