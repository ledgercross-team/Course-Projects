import React from "react";
import { Link } from "react-router-dom";
import { useWallet } from "../context/WalletContext.jsx";
import WalletConnect from "./WalletConnect.jsx";

export default function Navbar() {
  const { user, logout } = useWallet();

  return (
    <header
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "14px 32px",
        borderBottom: "1px solid var(--border)",
        background: "var(--surface)",
      }}
    >
      <Link to="/" style={{ textDecoration: "none", color: "var(--text)", fontWeight: 700, fontSize: 18 }}>
        🔐 SecureChain Will
      </Link>

      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        {user && (
          <span style={{ fontSize: 13, color: "var(--muted)" }}>
            {user.name} · <strong style={{ color: "var(--text)" }}>{user.role}</strong>
          </span>
        )}
        <WalletConnect />
        {user && (
          <button className="btn btn-secondary" onClick={logout}>
            Logout
          </button>
        )}
      </div>
    </header>
  );
}
