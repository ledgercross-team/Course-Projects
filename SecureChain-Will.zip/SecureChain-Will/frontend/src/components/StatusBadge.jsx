import React from "react";

const STYLES = {
  Created: { bg: "#334155", color: "#e2e8f0", label: "Created" },
  WitnessApproved: { bg: "#1e3a8a", color: "#bfdbfe", label: "Witness Approved" },
  Verified: { bg: "#78350f", color: "#fde68a", label: "Verified" },
  Released: { bg: "#14532d", color: "#bbf7d0", label: "Released" },
  Rejected: { bg: "#7f1d1d", color: "#fecaca", label: "Rejected" },
};

export default function StatusBadge({ status }) {
  const style = STYLES[status] || STYLES.Created;
  return (
    <span
      style={{
        display: "inline-block",
        padding: "4px 10px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 600,
        background: style.bg,
        color: style.color,
      }}
    >
      {style.label}
    </span>
  );
}
