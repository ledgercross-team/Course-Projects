import React from "react";
import { NavLink } from "react-router-dom";
import { useWallet } from "../context/WalletContext.jsx";

const LINKS_BY_ROLE = {
  creator: [
    { to: "/creator", label: "My Wills" },
    { to: "/upload", label: "Upload Will" },
  ],
  witness: [{ to: "/witness", label: "Assigned Wills" }],
  admin: [{ to: "/admin", label: "Admin Panel" }],
  beneficiary: [{ to: "/beneficiary", label: "Released Wills" }],
};

export default function Sidebar() {
  const { user } = useWallet();
  if (!user) return null;

  const links = LINKS_BY_ROLE[user.role] || [];

  return (
    <aside
      style={{
        width: 220,
        borderRight: "1px solid var(--border)",
        background: "var(--surface)",
        padding: "20px 12px",
      }}
    >
      <nav style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            style={({ isActive }) => ({
              padding: "10px 14px",
              borderRadius: 8,
              textDecoration: "none",
              color: isActive ? "white" : "var(--muted)",
              background: isActive ? "var(--primary)" : "transparent",
              fontSize: 14,
              fontWeight: 500,
            })}
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
