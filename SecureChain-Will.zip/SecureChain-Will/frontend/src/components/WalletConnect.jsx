import React from "react";
import { useWallet } from "../context/WalletContext.jsx";

function shorten(addr) {
  return addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : "";
}

export default function WalletConnect() {
  const { address, connect, connecting, error } = useWallet();

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      {address ? (
        <span
          className="card"
          style={{ padding: "6px 12px", fontSize: 13, fontFamily: "monospace" }}
        >
          🟢 {shorten(address)}
        </span>
      ) : (
        <button className="btn" onClick={connect} disabled={connecting}>
          {connecting ? "Connecting..." : "Connect MetaMask"}
        </button>
      )}
      {error && (
        <span style={{ color: "var(--danger)", fontSize: 12 }}>{error}</span>
      )}
    </div>
  );
}
