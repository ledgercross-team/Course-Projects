import React from "react";
import { Link } from "react-router-dom";
import StatusBadge from "./StatusBadge.jsx";

function shorten(addr) {
  return addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : "—";
}

export default function WillCard({ will, actions }) {
  return (
    <div className="card" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <strong style={{ fontSize: 15 }}>
          Will #{will.onChainId ?? "pending"}
        </strong>
        <StatusBadge status={will.status} />
      </div>

      <div style={{ fontSize: 13, color: "var(--muted)", display: "grid", gap: 4 }}>
        <div>Creator: {shorten(will.creatorWallet)}</div>
        <div>Witness: {shorten(will.witnessWallet)}</div>
        <div>Beneficiary: {shorten(will.beneficiaryWallet)}</div>
        <div>CID: {will.cid?.slice(0, 18)}...</div>
        <div>Created: {new Date(will.createdAt).toLocaleDateString()}</div>
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
        <Link className="btn btn-secondary" to={`/will/${will._id}`}>
          View
        </Link>
        {actions}
      </div>
    </div>
  );
}
