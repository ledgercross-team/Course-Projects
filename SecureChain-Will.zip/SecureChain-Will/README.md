# SecureChain Will

A blockchain-based digital will verification prototype. Built as a university
capstone project — **not a substitute for a legally binding will system.**

Documents are encrypted, pinned to IPFS, and referenced on-chain by hash and
CID only. Release to the beneficiary is gated behind witness approval and
admin verification, enforced both by Solidity modifiers and mirrored backend
role checks.

See `docs/` for the architecture diagram, database schema, API reference, and
user manual.

## Folder structure

```
SecureChain-Will/
├── smart-contract/   # Foundry project: WillRegistry.sol + tests + deploy script
├── backend/           # Express + MongoDB API: encryption, IPFS pinning, auth
├── frontend/           # React + Vite + ethers.js DApp
└── docs/                # Architecture, DB schema, API docs, user manual
```

## Prerequisites

- Node.js 18+
- MongoDB (local or Atlas)
- [Foundry](https://book.getfoundry.sh/getting-started/installation) (`curl -L https://foundry.paradigm.xyz | bash && foundryup`)
- A MetaMask wallet with Sepolia testnet ETH
- A [Pinata](https://www.pinata.cloud/) account (API key or JWT)
- An RPC URL for Sepolia (e.g. from Infura, Alchemy, or a public endpoint)

## 1. Smart contract

```bash
cd smart-contract
forge install foundry-rs/forge-std   # once, if not already vendored
forge build
forge test -vvv
```

Deploy to Sepolia:

```bash
export SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/<project-id>
export PRIVATE_KEY=<deployer-private-key>
export ETHERSCAN_API_KEY=<optional-for-verification>

forge script script/Deploy.s.sol:DeployWillRegistry \
  --rpc-url $SEPOLIA_RPC_URL \
  --private-key $PRIVATE_KEY \
  --broadcast --verify
```

Copy the deployed address — you'll need it in both `backend/.env` and
`frontend/.env` (`CONTRACT_ADDRESS` / `VITE_CONTRACT_ADDRESS`).

After building, copy the compiled ABI into the frontend so it stays in sync:

```bash
cp smart-contract/out/WillRegistry.sol/WillRegistry.json frontend/src/contracts/WillRegistry.json
```//A hand-written ABI is already checked in at that path so the frontend runs
without this step, but re-copying keeps it exact after any contract change.

## 2. Backend

```bash
cd backend
cp .env.example .env   # then fill in Mongo URI, JWT secret, AES key, Pinata keys,
                        # Sepolia RPC URL, deployed CONTRACT_ADDRESS, and an
                        # ADMIN_PRIVATE_KEY (a dedicated hot wallet — the
                        # contract's `admin` address).
npm install
npm run dev             # nodemon, http://localhost:5000
```

Generate a valid AES key quickly:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## 3. Frontend

```bash
cd frontend
cp .env.example .env    # set VITE_CONTRACT_ADDRESS to the deployed address
npm install
npm run dev              # http://localhost:5173
```

## Demonstration flow

1. Creator registers/logs in (MetaMask + signed message), uploads a scanned
   will, names a witness and beneficiary. Backend encrypts + pins to IPFS;
   frontend then calls `createWill()` on-chain.
2. Witness logs in, sees the assigned will, approves it (on-chain +
   mirrored in MongoDB).
3. Admin logs in, verifies the death/condition, then releases the will.
4. Beneficiary logs in and sees the will under **Released Wills**, with a
   download link to the encrypted document on IPFS.

## Security notes

- Only encrypted documents ever leave the creator's browser/backend for IPFS.
- The blockchain never stores document contents — only CID, SHA-256 hash,
  participant addresses, status, and timestamp.
- Role checks are enforced twice: on-chain (Solidity modifiers) and in the
  backend (JWT + role middleware) for defense in depth.
- Never commit `.env` files. `ADMIN_PRIVATE_KEY` should be a low-value,
  dedicated hot wallet used only for `verifyDeath`/`releaseWill` calls.

## Future scope

Multi-signature witness approval, government death registry integration,
digital signatures, time-locked release, email notifications, NFT
inheritance certificates, and AI document analysis are noted as future work
and are out of scope for this prototype.
